package emilsoft.completewordfinder;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Objects;


public class AnagramFragment extends Fragment {

    private Button find;
    private TextInputEditText textinput;
    private RecyclerView wordslist;
    private AnagramRecyclerViewAdapter adapter;

    private static final int[] PRIMES = new int[] { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31,
            37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103,
            107, 109, 113 };

    public AnagramFragment() {
        
    }

    public static AnagramFragment newInstance() {
        
        Bundle args = new Bundle();
        
        AnagramFragment fragment = new AnagramFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_anagram, container, false);
        textinput = (TextInputEditText) view.findViewById(R.id.textinput);
        find = (Button) view.findViewById(R.id.find_button);
        wordslist = (RecyclerView) view.findViewById(R.id.words_list);
        find.setOnClickListener(onClickListener);
        textinput.setOnFocusChangeListener(onFocusChangeListener);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                String textInserted = textinput.getText().toString();
                ArrayList<String> words = findAnagrams(textInserted,"280000_parole_italiane.txt");
                if (wordslist != null) {
                    adapter = new AnagramRecyclerViewAdapter(words);
                    wordslist.setAdapter(adapter);
                }
            } catch (NullPointerException ex) {
                Log.v(MainActivity.TAG, "text inserted is null");
            }
        }
    };

    private View.OnFocusChangeListener onFocusChangeListener = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if (hasFocus) {
                ConstraintLayout.LayoutParams parameter = (ConstraintLayout.LayoutParams) find.getLayoutParams();
                int pixel_topMargin = convertDPtoPX(Objects.requireNonNull(getActivity()), 12);
                parameter.setMargins(parameter.leftMargin, pixel_topMargin, parameter.rightMargin, parameter.bottomMargin);
                find.setLayoutParams(parameter);
                find.requestLayout();
            }
        }
    };

    private ArrayList<String> findAnagrams(String word, String filename) {
        if (word == null || filename == null)
            return null;
        ArrayList<String> words;
        long pw = calculateProduct(word.toUpperCase().toCharArray()); //Product of the word to match
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(getActivity().getAssets().open(filename)));
            String line;
            words = new ArrayList<>();
            while ((line = reader.readLine()) != null) {
                char[] letters = line.toUpperCase().toCharArray();
                long product = calculateProduct(letters);
                if (product == pw)
                    words.add(line);
            }
            reader.close();
            return words;
        } catch (IOException | NullPointerException ex) {
            ex.printStackTrace();
            Log.v(MainActivity.TAG, "exception in reading file");
            return null;
        }
    }

    private static long calculateProduct(char[] letters) {
        long result = 1L;
        for(char c: letters){
            if(c < 65)
                return -1;
            int pos = c - 65; //65 is the position of A in ASCII Table
            result *= PRIMES[pos];
        }
        return result;
    }

    public static int convertDPtoPX(Context context, int dp) {
        // Get the screen's density scale
        final float scale = context.getResources().getDisplayMetrics().density;
        // Convert the dps to pixels, based on density scale
        return (int) (dp * scale + 0.5f);
    }
}
