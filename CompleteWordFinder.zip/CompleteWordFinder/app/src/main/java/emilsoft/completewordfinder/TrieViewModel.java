package emilsoft.completewordfinder;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;

public class TrieViewModel extends AndroidViewModel {

    private final TrieLiveData mTrie;

    public TrieViewModel(Application application, String filename) {
        super(application);
        mTrie = new TrieLiveData(application, filename);
    }

    public LiveData<Trie> getTrie() {
        return mTrie;
    }

    public class TrieLiveData extends LiveData<Trie> {

        private final Context context;

        public TrieLiveData(Context context, String filename) {
            this.context = context;
            new CreateTrie().execute(filename);
        }

        private class CreateTrie extends AsyncTask<String, Void, Trie> {

            @Override
            protected Trie doInBackground(String... strings) {
                String filename = strings[0];
                Trie trie = new Trie();
                try {

                    //Read dictionary file
                    BufferedReader reader = new BufferedReader(new InputStreamReader(context.getAssets().open(filename)));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        trie.insert(line); //Should add .toLowerCase()?
                    }
                    reader.close();
                    trie.buildSuffixLinks();

                    //Write trie to file. So we skip to build it every time
                    FileOutputStream fos = context.openFileOutput(MainActivity.TRIE_FILENAME, Context.MODE_PRIVATE);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(trie);
                    oos.close();
                    fos.close();
                    return trie;
                } catch (IOException ex) {
                    ex.printStackTrace();
                    Log.v(MainActivity.TAG, "IOException while reading file");
                    return null;
                }
            }

            @Override
            protected void onPostExecute(Trie trie) {
                setValue(trie);
            }
        }

    }

}
